﻿Public Class Form1
    Private Sub btnPressMe_Click(sender As Object, e As EventArgs) Handles btnPressMe.Click
        MsgBox("Hello world!")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        ListBox1.Items.Add(ComboBox1.SelectedItem)
    End Sub
End Class
